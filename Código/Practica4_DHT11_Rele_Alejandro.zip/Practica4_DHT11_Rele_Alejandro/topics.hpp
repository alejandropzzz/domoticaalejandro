
const char* temperatura_topic = "casa/sensores/temperatura";
const char* humidade_topic = "casa/sensores/humidade";
const char* depuracion_topic = "depuracion";  
const char* rele_topic = "casa/actuadores/rele13";  
